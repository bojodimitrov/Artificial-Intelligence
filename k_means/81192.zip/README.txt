This is an exercise for implementing the kMeans algorithm for Homework#9 in the AI course of FMI.

=========

1. Install Python 3.
Optional: You can use Anaconda https://anaconda.org/anaconda/python
Optional: Setup an Python environment with Anaconda (https://conda.io/docs/user-guide/tasks/manage-environments.html): 

> conda create --name myenv

2. Install the dependencies:

> pip install dependencies.txt

3. Run the Jupyter notebook:

> jupyter notebook kMeans_Demo.ipynb

4. Perform the instructions in the notebook.
